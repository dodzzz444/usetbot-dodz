import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "1000"))

DEVS = list(map(int, os.getenv("DEVS", "").split()))

API_ID = int(os.getenv("28667868", ""))

API_HASH = os.getenv("d25ec0a150726d6670871d1780a7dbfc", "")

BOT_TOKEN = os.getenv("8160946253:AAGPPwb_CS1TX6IWzfzX7FS2jwQlc4kjd7w", "")

OWNER_ID = int(os.getenv("7114711934", ""))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285 -1002400165299 -1002416419679 -1001473548283").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT"))
